& { $BinaryFormatter = New-Object -TypeName System.Runtime.Serialization.Formatters.Binary.BinaryFormatter
 @{ 
'$this.Name' = 'AboutForm'
'Button1.Name' = 'Button1'
'RichTextBox1.Text' = 'UpdGUI is a simple front-end written in PowerShell for the PSWindowsUpdate module.

Version: 1.1

- Programming: CodingWonders (https://www.github.com/CodingWonders)
- Idea: og-mrk (https://www.github.com/og-mrk)

- Feedback is appreciated! Report any issues you may encounter or suggest new ideas in the Issues page
- Do you want to contribute? Follow the contribution guidelines at the bottom of the README file'
'RichTextBox1.Name' = 'RichTextBox1'
}
}